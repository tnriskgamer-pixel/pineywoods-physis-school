// Courses and requirements
const reqs=[
['Language Arts','5.0 Credits','2 semesters minimum for all students (at least 5 semesters for students going into humanities-based degrees).'],
['Math','4.0 Credits','Ecometrics in 1st year; 2nd, 3rd and 4th year are student choice.'],
['Science','4.0 Credits','Everyone takes a natural science course in 1st year; the rest are based on desired career (STEM students need 8 semesters, humanities students need 4).'],
['Fine Arts','1.0 Credit','Students choose the Fine Arts course they are most interested in.'],
['Foreign Language','1.0 Credit','Pass a test on ANY language covering basic reading, writing and understanding (hold a good conversation and answer questions about a text).'],
['Culture Studies','4.0 Credits','4 semesters required for humanities students (only 2 for STEM students).']];
$('reqCourses').innerHTML=reqs.map(r=>`<div class="card"><span class="tag">${r[1]}</span><h3>${r[0]}</h3><p>${r[2]}</p></div>`).join('');
const courses={
'Language Arts':['Advanced Composition I','Advanced Composition II H','Advanced Composition III (5.0)','AP Film and Screenwriting','Film and Screenwriting','Podcasting Honors','AP Digital Storytelling','Expository Writing I','Expository Writing I H','AP Expository Writing II'],
'Math':['Topological Landscapes AP','Topological Landscapes','Simulation Based Modeling Algorithms Honors','Simulation Based Modeling Algorithms','AP Ecometrics','Ecometrics','Climatics Honors','Climatics','Proceduralism','Proceduralism Honors'],
'Science':['AP Environmental Data Science','Environmental Data Science','Genomic Architects I','Genomic Architects II Honors','AP Analytical Syntax','Analytical Syntax','Heuristic Discoveries I','Heuristic Discoveries II'],
'Culture Studies':['American Culture AP','American Culture','History of Music H','History of Music','World Leaders','History of Inventions H','History of Inventions','History of Art AP','World Religions AP','World Religions'],
'Fine Arts':['Website Design H','Digital Art Fundamentals','AP 3D Modeling and Animation','Advanced Digital Media','Portfolio Development Honors','Native American Instrument Fundamentals','Darkroom Photography','Lithography Honors','Jewelry Design','Textile Engineering'],
'Foreign Languages':['Self Study I','Self Study II','Spanish Studies I','Spanish Studies II','Spanish Studies III AP','Chinese Studies I','Chinese Studies II AP','Accelerated Spanish Studies','ESL I','ESL 2']};
let cof='All';
function setCO(c){cof=c;drawCourses()}
function drawCourses(){filters('courseFilters',Object.keys(courses),cof,'setCO');
 $('courseList').innerHTML=Object.entries(courses).filter(e=>cof==='All'||e[0]===cof).map(e=>`<div class="card"><h3>${e[0]}</h3><ul style="margin:6px 0 0;padding-left:18px;font-size:14px;line-height:1.7">${e[1].map(c=>`<li>${c}</li>`).join('')}</ul></div>`).join('')}


drawCourses();
