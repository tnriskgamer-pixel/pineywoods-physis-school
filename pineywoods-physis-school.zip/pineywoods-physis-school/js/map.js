// Campus map data and pins
const B=[
{n:1,name:'Central Hub',sub:'General staff & reception',x:380,y:495,rooms:['Main Office & Administration (Rm 100)','Reception & Front Desk (Rm 101)','Main Announcements Room (Rm 102)','Student Lounge & Relax Area','Student & Staff Break Areas'],pcs:[['Help Desk Computers (Rm 101)',4,0,30]]},
{n:2,name:'Math, Ecometrics & Topological Landscapes Dept.',sub:'Math',x:300,y:240,rooms:['Topological Landscapes (Rm 201)','Ecometrics (Rm 202)','Climatics (Rm 203)','Proceduralism (Rm 204)','Simulation Based Modeling Algorithms (Rm 205)','Math Computer Lab (Rm 206)'],pcs:[['Math Computer Lab (Rm 206)',10,-50,32],['Ecometrics Data Corner (Rm 202)',6,10,40]]},
{n:3,name:'Fine Arts & Advanced Media Studios',sub:'Film, screenwriting, digital storytelling, art, 3D, portfolio',x:540,y:230,rooms:['Film & Screenwriting Studio (Rm 301)','Podcasting Studio (Rm 302)','Digital Storytelling (Rm 303)','Advanced Digital Media (Rm 304)','3D Modeling & Animation Lab (Rm 305)','Portfolio Development (Rm 306)'],pcs:[['3D Modeling & Animation Lab (Rm 305)',12,-60,60],['Media Editing Suite (Rm 304)',6,0,80]]},
{n:4,name:'Fine Arts & Art History AP',sub:'Simulation based modeling, genomic architects',x:200,y:355,rooms:['Art History AP (Rm 401)','Simulation Based Modeling Lab (Rm 402)','Genomic Architects Lab (Rm 403)','Art Studio (Rm 404)'],pcs:[['Simulation Modeling Lab (Rm 402)',8,-60,45]]},
{n:5,name:'Foreign Languages & Culture Studies Center',sub:'Languages and culture studies',x:660,y:410,rooms:['Spanish Studies (Rm 501)','Chinese Studies (Rm 502)','ESL Classroom (Rm 503)','American Culture & World Religions (Rm 504)','History of Music & Art (Rm 505)','Language Self-Study Lab (Rm 506)'],pcs:[['Language Self-Study Lab (Rm 506)',8,-10,110]]},
{n:6,name:'Language Arts: Advanced Composition & Fiction Labs',sub:'Language Arts',x:60,y:555,rooms:['Advanced Composition I-III (Rm 601-602)','Fiction Writing Lab (Rm 603)','Film & Screenwriting Workshop (Rm 604)'],pcs:[['Fiction Writing Computers (Rm 603)',6,100,60]]},
{n:7,name:'Language Arts: Advanced Composition & Expository Writing Labs',sub:'Language Arts',x:300,y:650,rooms:['Expository Writing Lab I (Rm 611)','Expository Writing Lab II (Rm 612)','Digital Storytelling Workshop (Rm 613)'],pcs:[['Expository Writing Computers (Rm 611)',6,-35,50]]},
{n:8,name:'Science: AP Environmental Data Science & Climatics Labs',sub:'Science',x:480,y:730,rooms:['AP Environmental Data Science Lab (Rm 701)','Climatics Lab (Rm 702)','Heuristic Discoveries (Rm 703)','Analytical Syntax (Rm 704)','Genomic Architects Lab (Rm 705)'],pcs:[['Data Science Lab (Rm 701)',10,10,100]]},
{n:9,name:'Outdoor AP Environmental Data Science & Climatics Labs',sub:'Outdoor science labs',x:565,y:625,rooms:['Outdoor AP Environmental Data Science Lab','Outdoor Climatics Lab (weather station)'],pcs:[['Field Weather Station Computers',2,10,45]]},
{n:10,name:'Outdoor Courtyard & Cultural Pavilions',sub:'Outdoor space',x:622,y:310,rooms:['Outdoor courtyard','Cultural pavilions','Space for club events'],pcs:[]},
{n:11,name:'Environmental Science & Outdoor Learning Spaces',sub:'Outdoor (planned)',x:672,y:722,rooms:['Environmental science spaces','Outdoor learning area'],pcs:[]},
{n:12,name:'Main Entrance',sub:'Front gate',x:368,y:815,rooms:['Front gate','Visitors check in at the Central Hub'],pcs:[]},
{n:13,name:'Track, Pool & Multi-Purpose Field',sub:'Athletics',x:170,y:800,rooms:['Track','Pool','Multi-purpose field'],pcs:[]}];
let selB=1,view='blue';
const pct=(x,y)=>`left:${x/7.2}%;top:${y/9.32}%`;
function setView(v){view=v;$('mapImg').style.display=v==='blue'?'block':'none';$('artImg').style.display=v==='art'?'block':'none';
 $('vBlue').classList.toggle('on',v==='blue');$('vArt').classList.toggle('on',v==='art');drawMap()}
function pick(n){selB=n;drawMap()}
function drawMap(){
 $('pins').innerHTML=view==='blue'?B.map(b=>`<button class="pin ${b.n===selB?'sel':''}" style="${pct(b.x,b.y)}" title="${b.name}" onclick="pick(${b.n})">${b.n}</button>`).join('')+($('showPC').checked?B.flatMap(b=>b.pcs.map(p=>`<button class="pc" style="${pct(b.x+p[2],b.y+p[3])}" title="${p[0]}: ${p[1]} stations" onclick="pick(${b.n})">💻</button>`)).join(''):''):'';
 const b=B.find(x=>x.n===selB);
 $('panel').innerHTML=`<span class="tag">Building ${b.n}</span><h2 style="margin:4px 0">${b.name}</h2><p style="color:var(--muted);margin:0">${b.sub}</p><h3>Rooms</h3><ul>${b.rooms.map(r=>`<li>${r}</li>`).join('')}</ul><h3>💻 Computer Stations</h3>`+(b.pcs.length?`<ul>${b.pcs.map(p=>`<li>${p[0]} - <b>${p[1]} stations</b></li>`).join('')}</ul>`:'<p class="pcs">No computer stations in this building.</p>');
 $('bList').innerHTML=B.map(x=>`<button class="${x.n===selB?'sel':''}" onclick="pick(${x.n})">${x.n}. ${x.name.split(':')[0].split(',')[0].split('&')[0]}</button>`).join('');
}
$('pcList').innerHTML=B.flatMap(b=>b.pcs.map(p=>`<div class="card" style="cursor:pointer" onclick="pick(${b.n})"><span class="tag">${p[1]} stations</span><h3>${p[0]}</h3><p>${b.name}</p></div>`)).join('');

drawMap();
