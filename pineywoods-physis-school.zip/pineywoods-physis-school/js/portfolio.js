// Portfolio projects
const pcats=['Robotics','Computer Science','Engineering','Art','Science'];
const projects=[
['🤖','Autonomous Robot','Robotics Team','A robot that follows a line and avoids obstacles on its own.','Robotics'],
['🌐','Student Website','Computer Science Team','A simple website where students can find school resources.','Computer Science'],
['🧩','3D Printed Model','Engineering Team','A scale model of our school campus printed in sections.','Engineering'],
['🎨','Piney Woods Mural','Art Club','A painted mural of local trees and animals for the hallway.','Art'],
['🌱','Mini Greenhouse','Science Club','A small greenhouse that tracks temperature and moisture.','Science'],
['📱','Lunch Menu App','Computer Science Team','A phone app that shows the daily cafeteria menu.','Computer Science']];
let pf='All';
function setPF(c){pf=c;drawProjects()}
function drawProjects(){filters('portFilters',pcats,pf,'setPF');
 $('projects').innerHTML=projects.filter(p=>pf==='All'||p[4]===pf).map(p=>`<div class="card"><div class="thumb">${p[0]}</div><span class="tag">${p[4]}</span><h3>${p[1]}</h3><p><b>By:</b> ${p[2]}</p><p>${p[3]}</p></div>`).join('')}


drawProjects();
