// Calendar events 2030-2040
const E=[
['2030-08-05','School Opens! 🎉','school','First day of the 2030–2031 school year at Pineywoods Physis School.'],
['2030-08-06','Locker & Schedule Help','school','Teachers and staff will help students find lockers and classrooms.'],
['2030-08-12','Club Sign-Up Day','club','Visit tables in the courtyard and join clubs.'],
['2030-08-15','Student Council Meeting','club','First meeting of the year. Room 101, 12:00 PM.'],
['2030-08-22','Robotics Interest Meeting','club','Robotics Lab, 3:30 PM. New members welcome.'],
['2030-08-29','Fall Project Idea Deadline','deadline','Submit your project idea to your teacher.'],
['2030-09-02','Labor Day','holiday','No school.'],
['2030-09-10','Chess Club Tournament','comp','Library, 3:30 PM. All skill levels.'],
['2030-09-13','Back-to-School Night','school','Families visit classrooms. 6:00 PM.'],
['2030-09-19','Debate Practice Round','club','Room 204, 3:30 PM.'],
['2030-09-26','Benchmark Testing','test','Testing in first and second periods.'],
['2030-10-03','Computer Science Club Hack Night','club','Room 112, 3:30 PM. Pizza provided.'],
['2030-10-11','Project Progress Check','deadline','Show your teacher your project progress.'],
['2030-10-18','Robotics Competition','comp','Regional meetup at the Pineywoods gym.'],
['2030-10-25','Fall Festival','school','Games, food, and booths after school.'],
['2030-10-31','Costume Day','school','Wear a school-appropriate costume!'],
['2030-11-06','Geocaching Club Hunt','club','Meet in front of the library, 12:00 PM.'],
['2030-11-12','Science Fair Entry Deadline','deadline','Turn in your science fair form.'],
['2030-11-14','Science Fair','comp','Gym, 9:00 AM – 2:00 PM.'],
['2030-11-20','Mid-Semester Testing','test','Check your schedule for test times.'],
['2030-11-27','Thanksgiving Break','holiday','No school Nov 27–29.'],
['2030-11-28','Thanksgiving Break','holiday','No school.'],
['2030-11-29','Thanksgiving Break','holiday','No school.'],
['2030-12-05','Portfolio Showcase Night','school','Students present their completed projects. 6:00 PM.'],
['2030-12-10','Art Club Winter Show','club','Art Room, 3:30 PM.'],
['2030-12-12','Final Project Deadline','deadline','Last day to submit semester projects.'],
['2030-12-16','Final Exams Begin','test','Exams run Dec 16–18.'],
['2030-12-20','Winter Break Begins','holiday','No school until January.']];
// ---- auto-generated events 2030-2040 (sample data) ----
const pad=n=>String(n).padStart(2,'0');
const ds=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const nth=(y,m,dow,n)=>{const f=new Date(y,m,1).getDay();return new Date(y,m,1+((dow-f+7)%7)+(n-1)*7)};
const last=(y,m,dow)=>{const l=new Date(y,m+1,0);return new Date(y,m,l.getDate()-((l.getDay()-dow+7)%7))};
const after=(y,m,d,dow)=>{const x=new Date(y,m,d);return new Date(y,m,d+((dow-x.getDay()+7)%7))};
const add=(d,n)=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+n);
const push=(d,t,k,x)=>E.push([ds(d),t,k,x]);
function spring(y){
 push(new Date(y,0,1),"New Year's Day",'holiday','No school.');
 push(after(y,0,2,1),'Classes Resume','school','First day back after winter break.');
 push(nth(y,0,1,3),'Martin Luther King Jr. Day','holiday','No school.');
 push(last(y,0,4),'Spring Project Idea Deadline','deadline','Submit your spring project idea to your teacher.');
 push(nth(y,1,5,2),'Robotics Competition','comp','Regional meetup at the Pineywoods gym.');
 push(nth(y,1,2,2),'Debate Club Tournament','comp','Room 204 and the library, 3:30 PM.');
 push(nth(y,1,1,3),"Presidents' Day",'holiday','No school.');
 const sb=nth(y,2,1,2);for(let i=0;i<5;i++)push(add(sb,i),'Spring Break','holiday','No school this week.');
 push(last(y,2,3),'Mid-Year Testing','test','Check your schedule for test times.');
 push(nth(y,3,4,1),'Chess Club Tournament','comp','Library, 3:30 PM. All skill levels.');
 push(nth(y,3,2,3),'Spring Benchmark Testing','test','Testing in first and second periods.');
 push(last(y,3,4),'Career Day','school','Guests visit to talk about their jobs.');
 push(nth(y,4,4,1),'Club Showcase','club','Clubs show off what they did this year in the courtyard.');
 push(nth(y,4,4,2),'Final Project Deadline','deadline','Last day to submit spring projects.');
 push(nth(y,4,1,3),'Final Exams Begin','test','Exams run Monday to Wednesday.');
 push(last(y,4,1),'Memorial Day','holiday','No school.');
 push(add(last(y,4,1),-3),'Awards Night','school','Student awards and portfolio showcase. 6:00 PM.');
 push(nth(y,4,5,4),'Last Day of School','school','Have a great summer!');
 push(nth(y,5,5,1),'Graduation','school','Graduation ceremony in the gym. 10:00 AM.');
}
function fall(y){
 const op=after(y,7,5,1);
 push(op,'School Opens! 🎉','school','First day of the new school year at Pineywoods Physis School.');
 push(add(op,7),'Club Sign-Up Day','club','Visit tables in the courtyard and join clubs.');
 push(add(op,10),'Student Council Meeting','club','First meeting of the year. Room 101, 12:00 PM.');
 push(last(y,7,4),'Fall Project Idea Deadline','deadline','Submit your project idea to your teacher.');
 push(nth(y,8,1,1),'Labor Day','holiday','No school.');
 push(nth(y,8,2,2),'Chess Club Tournament','comp','Library, 3:30 PM. All skill levels.');
 push(nth(y,8,4,2),'Back-to-School Night','school','Families visit classrooms. 6:00 PM.');
 push(last(y,8,4),'Benchmark Testing','test','Testing in first and second periods.');
 push(nth(y,9,4,1),'Computer Science Hack Night','club','Room 112, 3:30 PM. Pizza provided.');
 push(nth(y,9,5,2),'Project Progress Check','deadline','Show your teacher your project progress.');
 push(nth(y,9,5,3),'Robotics Competition','comp','Regional meetup at the Pineywoods gym.');
 push(last(y,9,5),'Fall Festival','school','Games, food, and booths after school.');
 push(new Date(y,9,31),'Costume Day','school','Wear a school-appropriate costume!');
 push(nth(y,10,3,1),'Geocaching Club Hunt','club','Meet in front of the library, 12:00 PM.');
 push(nth(y,10,2,1),'Science Fair Entry Deadline','deadline','Turn in your science fair form.');
 push(nth(y,10,4,2),'Science Fair','comp','Gym, 9:00 AM - 2:00 PM.');
 const tg=nth(y,10,4,4);[-1,0,1].forEach(i=>push(add(tg,i),'Thanksgiving Break','holiday','No school.'));
 push(nth(y,11,4,1),'Portfolio Showcase Night','school','Students present their completed projects. 6:00 PM.');
 push(nth(y,11,2,2),'Art Club Winter Show','club','Art Room, 3:30 PM.');
 push(nth(y,11,4,2),'Final Project Deadline','deadline','Last day to submit semester projects.');
 const ex=nth(y,11,1,3);
 push(ex,'Final Exams Begin','test','Exams run Monday to Wednesday.');
 push(add(ex,4),'Winter Break Begins','holiday','No school until January.');
}
for(let y=2031;y<=2040;y++){spring(y);fall(y)}
let cur=new Date(2030,7,1);
const MN=['January','February','March','April','May','June','July','August','September','October','November','December'];
function month(d){const n=new Date(cur.getFullYear(),cur.getMonth()+d,1);
 if(n<new Date(2030,7,1)||n>new Date(2040,11,1))return;cur=n;drawCal()}
function jump(){const y=+$('yrSel').value;cur=new Date(y,y===2030?Math.max(cur.getMonth(),7):y===2040?Math.min(cur.getMonth(),11):cur.getMonth(),1);drawCal()}
function drawCal(){const y=cur.getFullYear(),m=cur.getMonth();$('mTitle').textContent=MN[m]+' '+y;
 if(!$('yrSel').options.length)for(let i=2030;i<=2040;i++)$('yrSel').add(new Option(i,i));$('yrSel').value=y;
 let h=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>`<div class="dn">${d}</div>`).join('');
 const first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();
 for(let i=0;i<first;i++)h+='<div class="day blank"></div>';
 for(let d=1;d<=days;d++){const k=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
  const evs=E.map((e,i)=>[e,i]).filter(x=>x[0][0]===k).map(x=>`<button class="ev ${x[0][2]}" onclick="showEv(${x[1]})">${x[0][1]}</button>`).join('');
  h+=`<div class="day"><b>${d}</b>${evs}</div>`}
 $('cal').innerHTML=h}
function showEv(i){const e=E[i];const [y,m,d]=e[0].split('-');
 $('eTitle').textContent=e[1];$('eBody').innerHTML=`<b>${MN[+m-1]} ${+d}, ${y}</b><br><br>${e[3]}`;$('evModal').classList.add('show')}




drawCal();
