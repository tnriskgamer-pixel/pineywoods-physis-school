// Help Wanted posts and form
const cats=['Coding','Robotics','Design','Engineering','Art','Writing','Research'];
let posts=[
['Need a Programmer','Autonomous Robot','Python / Robotics',1,'Robotics'],
['Need a Designer','School App','Graphic Design',1,'Design'],
['Need a Coder','Club Sign-Up Website','HTML / JavaScript',2,'Coding'],
['Need a Writer','Science Newsletter','Writing / Editing',1,'Writing'],
['Need an Engineer','Water Filter Prototype','CAD / Building',2,'Engineering'],
['Need an Artist','Hallway Mural','Painting / Drawing',3,'Art'],
['Need a Researcher','Local Wildlife Study','Data Collection',1,'Research']].map(p=>({t:p[0],p:p[1],s:p[2],n:p[3],c:p[4]}));
let hf='All';
function setHF(c){hf=c;drawPosts()}
function drawPosts(){filters('helpFilters',cats,hf,'setHF');
 $('posts').innerHTML=posts.filter(p=>hf==='All'||p.c===hf).map((p,i)=>`<div class="card"><span class="tag">${p.c}</span><h3>${p.t}</h3><p><b>Project:</b> ${p.p}</p><p><b>Skills Needed:</b> ${p.s}</p><p><b>Students Needed:</b> ${p.n}</p><button class="btn alt" style="margin-top:8px" onclick="this.textContent='Request sent ✓'">I can help</button></div>`).join('')||'<p>No posts in this category yet.</p>'}
$('fCat').innerHTML=cats.map(c=>`<option>${c}</option>`).join('');
function openForm(){$('formModal').classList.add('show')}
function submitPost(){const t=$('fTitle').value.trim();if(!t){alert('Please enter a title');return}
 posts.unshift({t,p:$('fProject').value||'Untitled project',s:$('fSkills').value||'Any',n:$('fNum').value||1,c:$('fCat').value});
 ['fTitle','fProject','fSkills'].forEach(i=>$(i).value='');hf='All';drawPosts();closeModals()}


drawPosts();
