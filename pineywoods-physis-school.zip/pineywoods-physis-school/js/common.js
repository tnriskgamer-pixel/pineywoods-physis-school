// Shared helpers used on every page

const $=id=>document.getElementById(id);
function closeModals(){document.querySelectorAll('.modal').forEach(m=>m.classList.remove('show'))}
function filters(id,cats,cur,fn){$(id).innerHTML=['All',...cats].map(c=>`<button class="f ${c===cur?'on':''}" onclick="${fn}('${c}')">${c}</button>`).join('')}


document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModals()}));
