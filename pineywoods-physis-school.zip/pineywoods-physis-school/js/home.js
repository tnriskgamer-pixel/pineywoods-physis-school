// Workspace availability (sample data)
const spaces=[['💻','Computer Station','8 spots available',8,'green'],['🖨️','3D Printer','2 available',2,'yellow'],['🤖','Robotics Station','3 spots available',3,'yellow'],['🎨','Design Station','5 spots available',5,'green'],['🔬','Science Lab','Full right now',0,'red']];
$('spaces').innerHTML=spaces.map(s=>`<div class="card"><div class="ico">${s[0]}</div><h3>${s[1]}</h3><p><span class="dot ${s[4]}"></span>${s[2]}</p></div>`).join('');



