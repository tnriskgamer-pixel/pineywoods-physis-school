// Clubs list, search and filters
const clubs=[
['Computer Science Club','Learn to code, build apps, and play with tech.','Tuesdays 3:30 PM','Room 112','Mr. Alvarez','Technology'],
['Chess Club','Practice, play, and enter friendly tournaments.','Mondays 3:30 PM','Library','Ms. Turner','Games'],
['Robotics Club','Design and build robots for competitions.','Wednesdays 3:30 PM','Robotics Lab','Mr. Chen','Technology'],
['Art Club','Painting, drawing, and creative projects.','Thursdays 3:30 PM','Art Room','Ms. Rivera','Arts'],
['Debate Club','Practice public speaking and argument skills.','Tuesdays 3:30 PM','Room 204','Mr. Brooks','Academic'],
['Business Club','Learn about entrepreneurship and run mini businesses.','Fridays 3:30 PM','Room 108','Ms. Patel','Academic'],
['Student Council','Plan school events and represent students.','Mondays 12:00 PM','Room 101','Mrs. Hayes','Leadership'],
['Environmental Club','Recycling drives, tree planting, and campus cleanups.','Wednesdays 3:30 PM','Room 140','Ms. Nguyen','Outdoors'],
['Science Club','Experiments, demos, and science fair prep.','Thursdays 3:30 PM','Science Lab','Dr. Walker','Science'],
['Camping Club','Learn outdoor skills and plan weekend trips.','Fridays 12:00 PM','Gym Lobby','Mr. Boone','Outdoors'],
['Geology Club','Study rocks, minerals, and landforms.','Mondays 3:30 PM','Room 131','Dr. Stone','Science'],
['Geocaching Club','Treasure hunting with GPS around campus and town.','Wednesdays 12:00 PM','Room 118','Mr. Ortiz','Outdoors'],
['Wildlife Skills Club','Tracking, bird watching, and nature identification.','Tuesdays 12:00 PM','Courtyard','Ms. Foster','Outdoors'],
['Cooking Club','Try new recipes and learn kitchen basics.','Thursdays 3:30 PM','Family Science Room','Mrs. Dawson','Arts'],
['Entomology Club','Collect and study insects and other bugs.','Fridays 3:30 PM','Room 133','Dr. Marsh','Science'],
['Oceanic Science Club','Explore marine life and ocean ecosystems.','Mondays 12:00 PM','Room 135','Ms. Coral','Science']];
const ccats=['Technology','Science','Outdoors','Arts','Academic','Games','Leadership'];
let cf='All';
function setCF(c){cf=c;drawClubs()}
function drawClubs(){filters('clubFilters',ccats,cf,'setCF');const q=$('clubSearch').value.toLowerCase();
 $('clubList').innerHTML=clubs.filter((c,i)=>(cf==='All'||c[5]===cf)&&(c[0]+c[1]).toLowerCase().includes(q)).map(c=>{const code=c[0].split(' ').map(w=>w[0]).join('').toUpperCase()+'-'+(100+c[0].length*7);
 return `<div class="card"><span class="tag">${c[5]}</span><h3>${c[0]}</h3><p>${c[1]}</p><p>🕒 ${c[2]}</p><p>📍 ${c[3]}</p><p>👤 Sponsor: ${c[4]}</p><p>💬 Classroom code: <b>${code}</b></p></div>`}).join('')||'<p>No clubs found.</p>'}


drawClubs();
