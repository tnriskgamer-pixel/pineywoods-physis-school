PINEYWOODS PHYSIS SCHOOL WEBSITE (prototype)

HOW TO OPEN
Unzip this folder, then double-click index.html. No internet, login or database needed.

PAGES
index.html        Home + workspace availability
help-wanted.html  Help Wanted posts and "Post Help Wanted" form
portfolio.html    Student project portfolio
clubs.html        Clubs with search and filters
calendar.html     Calendar, August 2030 - December 2040
courses.html      Graduation requirements and courses
map.html          Interactive campus map with rooms and computer stations

FOLDERS
css/     style.css (colors, layout)
js/      one file per page - sample data (posts, clubs, events, rooms) lives here
images/  school logo and campus map pictures

HOW TO EDIT
Open the page's .js file in js/ to change sample data. Open css/style.css to change colors
(royal blue is --blue near the top).

HOW TO PUT IT ONLINE (free)
- Netlify Drop: go to app.netlify.com/drop and drag the whole folder onto the page.
- GitHub Pages: upload the folder to a GitHub repository and turn on Pages in Settings.
